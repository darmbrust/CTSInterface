This jar file comes from our CTS implementation - it is optional.  When it is here, the wsdl tool will use variable names from
this implementation, rather than using generic 'in0' variable names.