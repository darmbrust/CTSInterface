For current documentation, please see http://informatics.mayo.edu/LexGrid/index.php?page=ctsimpl

For support, please contact informatics@mayo.edu